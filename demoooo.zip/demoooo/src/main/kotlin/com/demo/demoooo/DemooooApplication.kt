package com.demo.demoooo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class DemooooApplication

fun main(args: Array<String>) {
	runApplication<DemooooApplication>(*args)
}
