package com.demo.demoooo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class DemooooApplicationTests {

	@Test
	fun contextLoads() {
	}

}
